import React from 'react'

function Footer() {
  return (
    <div>
      <h1  className='text-center bg-gray-200 p-4 text-2xl'>Developed by Himanshu  sharma🔥🔥🔥</h1>
       
    </div>
  )
}

export default Footer
